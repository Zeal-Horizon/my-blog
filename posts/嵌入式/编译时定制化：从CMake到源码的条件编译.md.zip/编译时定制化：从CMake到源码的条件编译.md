# 编译时定制化：从CMake到源码的条件编译

#### **一、问题概要：单板宏驱动的差异化管理**

#### **核心需求**

1. **多客户定制**：同一框架适配不同甲方，避免分支管理成本
2. **多硬件适配**：同一固件支持多种硬件配置（芯片、内存、外设）

#### **解决方案**

**CMake编译参数 + 源码条件编译**：通过编译时宏定义控制代码路径

---

### **二、完整配置链工作流程**

```
Shell脚本层       →      CMake构建层       →      源码编译层
（参数输入）           （配置转换）            （条件编译）
    ↓                      ↓                      ↓
./build.sh alpha      -DCLIENT=alpha        #ifdef CLIENT_ALPHA
   board_a            -DBOARD=board_a       initBoardAHardware()
```

---

### **三、各层实现详解**

#### **1. Shell脚本层：参数解析与传递**

```bash
#!/bin/bash
# 构建入口：./build.sh [客户] [板卡]
CLIENT=${1:-default}      # 客户参数，默认值default
BOARD=${2:-board_a}       # 板卡参数，默认值board_a

# 向CMake传递编译参数
cmake -B build -DCLIENT=${CLIENT} -DBOARD=${BOARD}
cmake --build build
```

#### **2. CMake层：宏定义配置**

```cmake
# CMakeLists.txt - 编译配置核心
set(CLIENT "default" CACHE STRING "客户名称")
set(BOARD "board_a" CACHE STRING "板卡型号")

# 根据参数设置单板宏
if(CLIENT STREQUAL "alpha")
    add_compile_definitions(CLIENT_ALPHA)    # → -DCLIENT_ALPHA
endif()

if(BOARD STREQUAL "board_a")
    add_compile_definitions(BOARD_A MEMORY_8K)  # → -DBOARD_A -DMEMORY_8K
endif()
```

#### **3. 源码层：条件编译实现**

```cpp
// main.cpp - 根据单板宏选择代码路径
int main() {
#ifdef CLIENT_ALPHA
    // Alpha客户专属功能
    enableAlphaFeatures();
#endif

#ifdef BOARD_A
    // 板卡A专用硬件初始化
    initBoardA();  // 仅当BOARD_A宏定义时编译
#endif
    return 0;
}
```

---

### **四、实际应用示例**

#### **场景一：Alpha客户板卡A版本**

```bash
# 构建命令
./build.sh alpha board_a

# 实际编译命令
g++ -DCLIENT_ALPHA -DBOARD_A -DMEMORY_8K main.cpp -o app

# 最终编译的代码
enableAlphaFeatures();  // Alpha客户功能
initBoardA();           // 板卡A硬件初始化
```

#### **场景二：默认客户板卡B版本**

```bash
# 构建命令  
./build.sh default board_b

# 实际编译命令
g++ -DBOARD_B -DMEMORY_512K main.cpp -o app

# 最终编译的代码
initBoardB();  // 板卡B硬件初始化
// 无Alpha客户功能代码（预处理器已移除）
```

‍
