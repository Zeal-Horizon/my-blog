# PX4+Ubuntu24.04 无人机仿真环境搭建  记录

参考文档：

[Ubuntu LTS/Debian Linux 的开发环境 | PX4 Guide (main)](assets/https://docs.px4.io/main/zh/dev_setup/dev_env_linux_ubuntu)

##### 一、PX4源码与工具部署

**1、主模块和子模块、工具拉取**

```c++
git clone https://github.com/PX4/PX4-Autopilot.git --recursive
```

在 bash shell 中运行无参数的 **ubuntu.sh** 来安装所有东西：

```c++
bash ./PX4-Autopilot/Tools/setup/ubuntu.sh
```

该部分可能会遇到拉取失败的问题，可以重置子模块：

```c++
git submodule deinit -f .
git submodule init
git submodule update --init --recursive --force
```

或者重新执行上面的操作拉取

**2、编译默认目标**

```c++
make px4_sitl gz_x500
```

可能遇到如下问题

```c++
root@zh-vm:/home/workSpace/VIOS/PX4-Autopilot# make px4_sitl gz_x500
ninja: error: unknown target 'gz_x500'
make: *** [Makefile:227：px4_sitl] 错误 1
root@zh-vm:/home/workSpace/VIOS/PX4-Autopilot# 
```

**该问题为缺少 Gazebo 仿真环境的依赖项，询问AI后做如下配置**

```c++
# 添加 Gazebo 仓库
sudo wget https://packages.osrfoundation.org/gazebo.gpg -O /usr/share/keyrings/pkgs-osrf-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/pkgs-osrf-archive-keyring.gpg] http://packages.osrfoundation.org/gazebo/ubuntu-stable $(lsb_release -cs) main" | sudo tee /etc/apt/sources.list.d/gazebo-stable.list > /dev/null

sudo apt update
sudo apt install gz-harmonic
```

**配置以后**

‍
