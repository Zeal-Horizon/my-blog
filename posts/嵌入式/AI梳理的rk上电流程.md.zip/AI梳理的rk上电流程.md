# AI梳理的rk上电流程

好，我来重新梳理Rockchip平台下完整的WiFi驱动加载流程，把之前讨论的所有代码串联起来。

## **Rockchip平台WiFi驱动完整加载流程**

### **第一阶段：平台驱动准备 (rfkill-wlan.c)**

```c
// drivers/net/wireless/rockchip_wlan/rfkill-wlan.c

// 1. 模块初始化入口
static int __init rfkill_wlan_init(void)
{
    LOG("Enter %s\n", __FUNCTION__);
    // 注册平台驱动
    return platform_driver_register(&rfkill_wlan_driver);
}

// 2. 平台驱动结构
static struct platform_driver rfkill_wlan_driver = {
    .probe = rfkill_wlan_probe,           // 设备匹配时调用
    .remove = rfkill_wlan_remove,
    .driver = {
        .name = "wlan-platdata",
        .of_match_table = wlan_platdata_of_match,  // 设备树匹配表
    },
};

// 3. 设备树匹配表
#ifdef CONFIG_OF
static struct of_device_id wlan_platdata_of_match[] = {
    { .compatible = "wlan-platdata" },    // 匹配设备树节点
    {}
};
#endif

// 4. probe函数 - 设备树匹配成功后调用
static int rfkill_wlan_probe(struct platform_device *pdev)
{
    struct rfkill_wlan_data *rfkill;
    struct rksdmmc_gpio_wifi_moudle *pdata;
    
    LOG("Enter %s\n", __FUNCTION__);
    
    // 4.1 解析设备树配置
#ifdef CONFIG_OF
    pdata = kzalloc(sizeof(*pdata), GFP_KERNEL);
    wlan_platdata_parse_dt(&pdev->dev, pdata);
    // 解析的内容包括：
    // - wifi_chip_type = "AP6275HH3"    // WiFi芯片类型
    // - WIFI,poweren_gpio               // 电源控制GPIO
    // - WIFI,host_wake_irq              // OOB中断引脚
    // - power_ctrl_by_pmu                // 是否使用PMU控制
#endif

    // 4.2 保存平台数据
    rfkill = kzalloc(sizeof(*rfkill), GFP_KERNEL);
    rfkill->pdata = pdata;
    g_rfkill = rfkill;  // 保存为全局变量，供其他模块使用

    // 4.3 初始化GPIO（如果是GPIO控制方式）
    if (!pdata->mregulator.power_ctrl_by_pmu) {
        // 申请VBAT GPIO
        rfkill_rk_setup_gpio(&pdata->vbat_n, "rkwifi", "wlan_vbat");
        // 申请RESET GPIO
        rfkill_rk_setup_gpio(&pdata->reset_n, "rkwifi", "wlan_reset");
    }

    // 4.4 默认打开VBAT电源
    rfkill_set_wifi_bt_power(1);
    
    // 4.5 如果需要保持电源，立即上电
    if (pdata->wifi_power_remain)
        rockchip_wifi_power(1);

    // 4.6 创建sysfs接口
    class_register(&rkwifi_power);
    
    LOG("Exit %s\n", __FUNCTION__);
    return 0;
}

// 5. 导出的电源控制函数（供dhd模块调用）
EXPORT_SYMBOL(rockchip_wifi_power);         // WiFi主电源控制
EXPORT_SYMBOL(rfkill_set_wifi_bt_power);    // VBAT电源控制
EXPORT_SYMBOL(rockchip_wifi_get_oob_irq);   // 获取OOB中断号
```

### **第二阶段：设备树配置**

```dts
// arch/arm/boot/dts/rockchip/rk3288.dtsi 或具体板级dts

/ {
    // WiFi平台数据节点
    wlan-platdata {
        compatible = "wlan-platdata";           // 匹配rfkill-wlan.c
        wifi_chip_type = "AP6275HH3";           // Broadcom芯片
        
        // GPIO控制引脚（Rockchip GPIO）
        WIFI,poweren_gpio = <&gpio7 RK_PA0 GPIO_ACTIVE_HIGH>;
        WIFI,vbat_gpio = <&gpio7 RK_PA1 GPIO_ACTIVE_HIGH>;
        WIFI,reset_gpio = <&gpio7 RK_PA2 GPIO_ACTIVE_HIGH>;
        WIFI,host_wake_irq = <&gpio7 RK_PA3 GPIO_ACTIVE_HIGH>;
        
        // 或者使用PMU控制（可选）
        // power_ctrl_by_pmu;
        // power_pmu_regulator = "vdd_wifi";
        // power_pmu_enable_level = <1>;
        
        // 保持WiFi电源
        keep_wifi_power_on;
        
        // 外部时钟频率
        ref-clock-frequency = <24000000>;
    };

    // SDIO控制器配置
    &sdio0 {
        status = "okay";
        bus-width = <4>;
        non-removable;              // 非热插拔
        cap-sd-highspeed;
        sd-uhs-sdr50;
        
        // WiFi芯片作为SDIO设备
        brcmf: wifi@1 {
            reg = <1>;
            compatible = "brcm,bcm4329-fmac";
            interrupt-parent = <&gpio7>;
            interrupts = <RK_PA3 IRQ_TYPE_EDGE_FALLING>;  // OOB中断
        };
    };
};
```

### **第三阶段：dhd模块初始化**

```c
// drivers/net/wireless/broadcom/bcmdhd/dhd_linux.c

// 1. dhd模块初始化入口
static int __init rockchip_wifi_init_module_rkwifi(void)
{
    printk("%s: in %s\n", __FUNCTION__, dhd_version);
    
    // 调用dhd模块初始化
    return dhd_module_init();
}

// 2. dhd模块初始化
static int dhd_module_init(void)
{
    int err;
    
    err = _dhd_module_init();
    return err;
}

// 3. 核心初始化函数
static int _dhd_module_init(void)
{
    int err;
    int retry = POWERUP_MAX_RETRY;  // 重试次数，通常为3次
    
    printk("%s: in %s\n", __FUNCTION__, dhd_version);
    
    // 保存原始固件路径（用于重试）
    if (firmware_path[0] != '\0') {
        strlcpy(fw_bak_path, firmware_path, sizeof(fw_bak_path));
    }
    if (nvram_path[0] != '\0') {
        strlcpy(nv_bak_path, nvram_path, sizeof(nv_bak_path));
    }
    
    do {
        // 4. 关键函数：注册平台驱动并获取硬件信息
        err = dhd_wifi_platform_register_drv();
        
        if (!err) {
            register_reboot_notifier(&dhd_reboot_notifier);
            break;
        } else {
            DHD_ERROR(("Failed to load the driver, try cnt %d\n", retry));
            // 失败后恢复路径，准备重试
            strlcpy(firmware_path, fw_bak_path, sizeof(firmware_path));
            strlcpy(nvram_path, nv_bak_path, sizeof(nvram_path));
        }
    } while (retry--);
    
    // 5. 创建Netlink socket（用于和用户态通信）
    dhd_create_to_notifier_skt();
    
    printf("%s: Exit err=%d\n", __FUNCTION__, err);
    return err;
}
```

### **第四阶段：平台驱动注册与信息获取**

```c
// drivers/net/wireless/broadcom/bcmdhd/dhd_platform.c

int dhd_wifi_platform_register_drv(void)
{
    int err = 0;
    
    DHD_INFO(("%s: Enter\n", __FUNCTION__));
    
    // 在Rockchip平台上，这里会尝试注册WiFi控制函数驱动
    err = wifi_ctrlfunc_register_drv();
    
    if (err) {
        if (err == -ENXIO) {
            // 理论上Rockchip平台不会走这里，因为rfkill-wlan.c提供了平台数据
            err = dhd_wifi_platform_load();
        } else {
            wifi_ctrlfunc_unregister_drv();
        }
    }
    
    return err;
}

// WiFi控制函数驱动注册
static int wifi_ctrlfunc_register_drv(void)
{
    int err;
    
    DHD_INFO(("%s: Registering WiFi control function driver\n", __FUNCTION__));
    
    // 注册平台驱动
    err = platform_driver_register(&wifi_ctrlfunc_driver);
    if (err) {
        DHD_ERROR(("%s: platform_driver_register failed\n", __FUNCTION__));
        return err;
    }
    
    // 等待平台设备就绪
    err = wifi_ctrlfunc_wait_for_dev();
    if (err) {
        platform_driver_unregister(&wifi_ctrlfunc_driver);
        return err;
    }
    
    return 0;
}

// WiFi控制函数驱动结构
static struct platform_driver wifi_ctrlfunc_driver = {
    .probe = wifi_ctrlfunc_probe,      // 当设备匹配时调用
    .remove = wifi_ctrlfunc_remove,
    .driver = {
        .name = "bcmdhd_wifi_ctrlfunc",
        .owner = THIS_MODULE,
    },
};

// probe函数 - 获取rfkill-wlan.c提供的平台数据
static int wifi_ctrlfunc_probe(struct platform_device *pdev)
{
    struct wifi_platform_data *plat_data;
    
    DHD_INFO(("%s: Enter\n", __FUNCTION__));
    
    // 获取平台数据（来自rfkill-wlan.c）
    plat_data = (struct wifi_platform_data *)pdev->dev.platform_data;
    
    if (plat_data) {
        // 关键：保存rfkill-wlan.c提供的函数指针
        dhd_plat_data.set_power = plat_data->set_power;          // rockchip_wifi_power
        dhd_plat_data.set_carddetect = plat_data->set_carddetect; // rockchip_wifi_set_carddetect
        dhd_plat_data.get_oob_irq = plat_data->get_oob_irq;      // rockchip_wifi_get_oob_irq
        
        DHD_INFO(("Got platform data: set_power=%p, get_oob_irq=%p\n",
            dhd_plat_data.set_power, dhd_plat_data.get_oob_irq));
    }
    
    return 0;
}
```

### **第五阶段：SDIO驱动注册**

```c
// drivers/net/wireless/broadcom/bcmdhd/bcmsdh.c

int bcmsdh_register(void)
{
    int error = 0;
    
    DHD_TRACE(("%s: Enter\n", __FUNCTION__));
    
    // 注册SDIO客户端驱动
    error = bcmsdh_register_client();
    
    return error;
}

int bcmsdh_register_client(void)
{
    int error = 0;
    
    DHD_TRACE(("%s: Enter\n", __FUNCTION__));
    
    // 注册SDIO驱动
    error = sdio_register_driver(&bcmsdh_sdmmc_driver);
    
    return error;
}

// SDIO驱动结构
static struct sdio_driver bcmsdh_sdmmc_driver = {
    .name = "bcmsdh_sdmmc",
    .id_table = bcmsdh_sdmmc_ids,      // 支持的芯片ID表
    .probe = bcmsdh_sdmmc_probe,        // 设备匹配时调用
    .remove = bcmsdh_sdmmc_remove,
};

// 支持的Broadcom芯片ID表
static const struct sdio_device_id bcmsdh_sdmmc_ids[] = {
    { SDIO_DEVICE(SDIO_VENDOR_ID_BROADCOM, SDIO_DEVICE_ID_BROADCOM_4335) },
    { SDIO_DEVICE(SDIO_VENDOR_ID_BROADCOM, SDIO_DEVICE_ID_BROADCOM_4339) },
    { SDIO_DEVICE(SDIO_VENDOR_ID_BROADCOM, SDIO_DEVICE_ID_BROADCOM_4345) },
    { SDIO_DEVICE(SDIO_VENDOR_ID_BROADCOM, SDIO_DEVICE_ID_BROADCOM_4354) },
    // ... 其他芯片ID
    { } /* terminate */
};
```

### **第六阶段：WiFi芯片上电**

```c
// drivers/net/wireless/broadcom/bcmdhd/dhd_sdio.c

static int dhdsdio_probe(struct sdio_func *func)
{
    dhd_pub_t *dhd;
    int ret;
    
    DHD_TRACE(("%s: Enter\n", __FUNCTION__));
    
    // 1. 调用平台电源函数，给WiFi上电
    if (dhd_plat_data.set_power) {
        // 调用rockchip_wifi_power(1)
        dhd_plat_data.set_power(1);
        
        // 等待硬件稳定
        msleep(WIFI_TURNON_DELAY);
    }
    
    // 2. 触发SDIO总线枚举，让内核重新扫描
    if (dhd_plat_data.set_carddetect) {
        // 调用rockchip_wifi_set_carddetect(1)
        dhd_plat_data.set_carddetect(1);
    }
    
    // 3. 使能SDIO功能
    sdio_claim_host(func);
    ret = sdio_enable_func(func);
    sdio_release_host(func);
    
    // 4. 设置块大小
    sdio_claim_host(func);
    ret = sdio_set_block_size(func, 64);
    sdio_release_host(func);
    
    // 5. 注册OOB中断（如果提供了中断号）
    if (dhd_plat_data.get_oob_irq) {
        int irq = dhd_plat_data.get_oob_irq();  // 获取中断号
        if (irq > 0) {
            request_irq(irq, dhd_oob_irq_handler,
                       IRQF_TRIGGER_FALLING, "bcmdhd_oob", dhd);
        }
    }
    
    // 6. 继续dhd核心初始化
    ret = dhd_attach(&dhd->pub, &func->dev, 0);
    
    return ret;
}
```

### **第七阶段：MMC核心枚举**

```c
// drivers/mmc/core/sdio.c

void mmc_rescan(struct work_struct *work)
{
    struct mmc_host *host = container_of(work, struct mmc_host, detect_work);
    u32 ocr;
    int err;
    
    // 1. 发送CMD0，复位设备
    mmc_go_idle(host);
    
    // 2. 发送CMD5，获取OCR
    err = mmc_send_op_cond(host, 0, &ocr);
    
    // 3. 发送CMD3，获取RCA
    err = mmc_send_relative_addr(host, &rca);
    
    // 4. 发送CMD9，读取CSD
    err = mmc_send_csd(host, csd);
    
    // 5. 关键：读取SDIO的FBR，获取VID/PID
    err = sdio_read_fbr(host, func);
    
    // 6. 获取到的设备信息
    u16 vendor = func->vendor;   // 例如 0x02D0 (Broadcom)
    u16 device = func->device;   // 例如 0x4335 (BCM4335)
    
    printk(KERN_INFO "Found SDIO device: vendor=0x%04x, device=0x%04x\n",
           vendor, device);
    
    // 7. 设备匹配：遍历所有SDIO驱动
    err = device_attach(&func->dev);  // 这会触发驱动的probe
}
```

### **第八阶段：设备匹配成功，dhd核心初始化**

```c
// drivers/net/wireless/broadcom/bcmdhd/dhd_linux.c

dhd_pub_t * dhd_attach(osl_t *osh, struct dhd_bus *bus, uint bus_hdrlen)
{
    dhd_info_t *dhd = NULL;
    struct net_device *net;
    
    DHD_TRACE(("%s: Enter\n", __FUNCTION__));
    
    // 1. 获取适配器信息（从rfkill-wlan.c）
    dhd_bus_get_ids(bus, &bus_type, &bus_num, &slot_num);
    adapter = dhd_wifi_platform_get_adapter(bus_type, bus_num, slot_num);
    
    // 2. 分配dhd_info结构体
    dhd = MALLOC(osh, sizeof(dhd_info_t));
    memset(dhd, 0, sizeof(dhd_info_t));
    
    // 3. 保存适配器信息
    dhd->adapter = adapter;
    g_dhd_pub = &dhd->pub;
    
    // 4. 配置解析
    dhd_conf_attach(&dhd->pub);
    
    // 5. 更新固件路径
    dhd_update_fw_nv_path(dhd);
    
    // 6. 创建网络接口
    net = dhd_allocate_if(&dhd->pub, 0, "wlan%d", NULL, 0, TRUE, NULL);
    
    // 7. 协议层初始化
    dhd_prot_attach(&dhd->pub);
    
    // 8. cfg80211初始化
#ifdef WL_CFG80211
    wl_cfg80211_attach(net, &dhd->pub);
#endif
    
    // 9. 下载固件并同步
    dhd_bus_start(&dhd->pub);
    
    return &dhd->pub;
}

// 固件下载和同步
int dhd_bus_start(dhd_pub_t *dhdp)
{
    // 1. 下载固件
    ret = dhd_bus_download_firmware(dhdp->bus, dhdp->osh,
                                     dhd->fw_path, dhd->nv_path,
                                     dhd->clm_path, dhd->conf_path);
    
    // 2. 启动看门狗
    dhd_os_wd_timer(dhdp, dhd_watchdog_ms);
    
    // 3. 总线初始化
    dhd_bus_init(dhdp, FALSE);
    
    // 4. 与dongle同步
    ret = dhd_sync_with_dongle(dhdp);
    
    return ret;
}
```

### **第九阶段：网络设备注册**

```c
// drivers/net/wireless/broadcom/bcmdhd/dhd_linux.c

int dhd_register_if(dhd_pub_t *dhdp, int ifidx, bool need_rtnl_lock)
{
    dhd_info_t *dhd = (dhd_info_t *)dhdp->info;
    struct net_device *net;
    int err;
    
    net = dhd->iflist[ifidx]->net;
    
    // 设置网络设备操作函数
    net->netdev_ops = &dhd_ops_pri;
    
    // 设置MAC地址（从固件读取或平台获取）
    dev_addr_set(net, dhd->pub.mac.octet);
    
    // 注册网络设备
    err = register_netdev(net);
    
    printk("Register interface [%s]  MAC: %pM\n", net->name, net->dev_addr);
    
    return err;
}
```

## **完整流程图**

```
系统启动
    │
    ▼
[内核启动设备树解析]
    ├─ 解析 wlan-platdata 节点
    └─ 创建 platform_device
    │
    ▼
[rk] drivers/net/wireless/rockchip_wlan/rfkill-wlan.c
    ├─ module_init(rfkill_wlan_init)
    ├─ platform_driver_register(&rfkill_wlan_driver)
    ├─ 设备树匹配成功 → rfkill_wlan_probe()
    │   ├─ wlan_platdata_parse_dt()      // 解析GPIO、芯片类型
    │   ├─ 初始化电源控制GPIO
    │   ├─ rfkill_set_wifi_bt_power(1)   // 打开VBAT
    │   ├─ rockchip_wifi_power(1)         // 打开主电源
    │   └─ 导出函数 (EXPORT_SYMBOL)
    │       ├─ rockchip_wifi_power
    │       ├─ rockchip_wifi_get_oob_irq
    │       └─ rockchip_wifi_set_carddetect
    │
    ▼
[rk] drivers/net/wireless/broadcom/bcmdhd/dhd_linux.c
    ├─ module_init(rockchip_wifi_init_module_rkwifi)
    ├─ dhd_module_init()
    ├─ _dhd_module_init()
    │   ├─ dhd_wifi_platform_register_drv()
    │   │   ├─ wifi_ctrlfunc_register_drv()
    │   │   │   ├─ platform_driver_register()
    │   │   │   ├─ wifi_ctrlfunc_wait_for_dev()
    │   │   │   └─ wifi_ctrlfunc_probe()
    │   │   │       └─ 获取并保存平台函数指针
    │   │   │           ├─ set_power = rockchip_wifi_power
    │   │   │           ├─ get_oob_irq = rockchip_wifi_get_oob_irq
    │   │   │           └─ set_carddetect = rockchip_wifi_set_carddetect
    │   │   └─ dhd_create_to_notifier_skt()
    │   │
    │   └─ bcmsdh_register()
    │       └─ sdio_register_driver(&bcmsdh_sdmmc_driver)
    │
    ▼
[SDIO Core] drivers/mmc/core/sdio.c
    ├─ mmc_rescan() 被调度
    ├─ 发送SDIO命令读取设备信息
    ├─ 获取 VID=0x02D0, PID=0x4335
    └─ 设备匹配 → 调用 bcmsdh_sdmmc_probe()
    │
    ▼
[rk] drivers/net/wireless/broadcom/bcmdhd/bcmsdh.c
    └─ bcmsdh_sdmmc_probe()
        ├─ 调用保存的平台函数上电
        │   └─ rockchip_wifi_power(1)     // 通过GPIO上电
        ├─ 调用平台函数触发枚举
        │   └─ rockchip_wifi_set_carddetect(1)
        ├─ sdio_enable_func()
        ├─ sdio_set_block_size()
        ├─ 获取OOB中断号
        │   └─ rockchip_wifi_get_oob_irq()
        ├─ request_irq() 注册中断处理
        └─ dhd_attach()
            ├─ dhd_allocate_if()          // 创建net_device
            ├─ dhd_prot_attach()           // 协议初始化
            ├─ wl_cfg80211_attach()        // cfg80211注册
            ├─ dhd_bus_start()              // 下载固件
            │   ├─ dhd_bus_download_firmware()
            │   ├─ dhd_bus_init()
            │   └─ dhd_sync_with_dongle()
            └─ dhd_register_if()            // 注册网络设备
                └─ register_netdev()        // wlan0 设备创建
    │
    ▼
[系统就绪] wlan0 网络设备可用
    ├─ /sys/class/rkwifi/ 接口可用
    ├─ 可以通过 iwconfig/wpa_supplicant 配置WiFi
    └─ 电源状态可以通过 sysfs 控制
        ├─ echo 1 > /sys/class/rkwifi/wifi_power   // 手动上电
        └─ echo 0 > /sys/class/rkwifi/wifi_power   // 手动断电
```

## **关键函数调用关系**

```c
// rfkill-wlan.c 提供的接口
rockchip_wifi_power()                 → GPIO操作上电/断电
rockchip_wifi_get_oob_irq()            → 返回OOB中断号
rockchip_wifi_set_carddetect()         → 触发SDIO枚举

// dhd模块保存的函数指针
dhd_plat_data.set_power = rockchip_wifi_power
dhd_plat_data.get_oob_irq = rockchip_wifi_get_oob_irq
dhd_plat_data.set_carddetect = rockchip_wifi_set_carddetect

// 实际调用位置
dhdsdio_probe() → dhd_plat_data.set_power(1)    // 上电
dhdsdio_probe() → dhd_plat_data.get_oob_irq()   // 获取中断号
dhd_bus_start() → dhd_plat_data.set_power(1)    // 固件下载前确保上电
```

这个流程展示了Rockchip平台下，`rfkill-wlan.c`​和`dhd`模块如何协同工作，通过函数指针解耦电源控制逻辑，最终完成WiFi驱动的完整加载。
