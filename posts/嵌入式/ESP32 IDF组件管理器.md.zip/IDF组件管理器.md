# IDF组件管理器

1、创建简单例程

2、进入组件管理器网页

‍

此时：

![image](assets/image-20260416222846-3lm69he.png)

添加完以后：sample_project\main\idf_component.yml

```undefined
## IDF Component Manager Manifest File
dependencies:
  ## Required IDF version
  idf:
    version: '>=4.1.0'
  # # Put list of dependencies here
  # # For components maintained by Espressif:
  # component: "~1.0.0"
  # # For 3rd party components:
  # username/component: ">=1.0.0,<2.0.0"
  # username2/component2:
  #   version: "~1.0.0"
  #   # For transient dependencies `public` flag can be set.
  #   # `public` flag doesn't have an effect dependencies of the `main` component.
  #   # All dependencies of `main` are public by default.
  #   public: true
  jbrilha/esp_lcd_st7789: ^1.0.2
  lvgl/lvgl: ^9.3.0
```

整体结构就变成这样了：

![image](assets/image-20260416222941-23zgmpy.png)

三、配置

此时，多出了这个：

![image](assets/image-20260416223441-lo75mku.png)

四、编写

你的逻辑代码应该写在 `main/main.c` 里。你的主要任务是：

1. ​**初始化屏幕驱动**​：调用 `st7789` 相关的初始化函数。
2. ​**初始化 LVGL**​：调用 `lv_init()`。
3. ​**注册显示驱动**：告诉 LVGL 你的屏幕多大、怎么刷新。
4. **创建界面**：用 LVGL 的 API 画按钮、标签等。

‍

‍

```undefined
                 from E:/ESP32/my_first_project/sample_project/sample_project/managed_components/lvgl__lvgl/src/core/lv_obj_property.c:9:
E:/ESP32/my_first_project/sample_project/sample_project/managed_components/lvgl__lvgl/src/lv_conf_internal.h:58:18: fatal error: lv_conf.h: No such file or directory
   58 |         #include "lv_conf.h"
      |                  ^~~~~~~~~~~
compilation terminated.
[888/1711] Performing configure step for 'bootloader'
-- Found Git: E:/program_files/Git/cmd/git.exe (found version "2.53.0.windows.2")
```
